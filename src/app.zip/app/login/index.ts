/**
 * This barrel file provides the export for the lazy loaded AboutComponent.
 */
export * from './login.component';
export * from './login.routes';
