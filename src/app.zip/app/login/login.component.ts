import { Component } from '@angular/core';

/**
*  This class represents the lazy loaded LoginComponent.
*/

@Component({
  selector: 'login',
  templateUrl: 'login.component.html'
})

export class LoginComponent { }
